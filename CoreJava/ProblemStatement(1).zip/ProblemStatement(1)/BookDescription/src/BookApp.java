import java.util.ArrayList;
import java.util.Scanner;

public class BookApp{
	 
	 static Scanner input = new Scanner(System.in);
	 static ArrayList<Book> listOfBooks = new ArrayList<>();
	 
	 public static void main(String[] args) {
		 listOfBooks.add (new Book("Java Programming", 100));
		 listOfBooks.add(new Book("Let us C", 900));
	}
	
	 //to view books
	 public static void showBooks() {
		 listOfBooks.forEach((book) -> System.out.println(book));
	 }
	 
	 // to add book
	 
//	 public static void createBook() {
//		 String book_title;
//		 int book_price;
//		 
//		 System.out.println("enter the name of the book");
//		 book_title=input.next();
//		 
//		 System.out.println("enter the price of the book");
//		 book_price=input.nextInt();
//		 
//		 listOfBooks.add(new Book(book_title, book_price));
//		 System.out.println("Book added successfully");
//	 }
}
class Book{
	
	private String book_title;
	private int book_price;
	
	@Override
	public String toString() {
		return "Book [book_title=" + book_title + ", book_price=" + book_price + "]";
	}
	
    public Book(String book_title, int book_price) {
		
		this.book_title = book_title;
		this.book_price = book_price;
	}
	
	public String getBook_title() {
		return book_title;
	}
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	
	public int getBook_price() {
		return book_price;
	}
	public void setBook_price(int book_price) {
		this.book_price = book_price;
	}
	
	
}