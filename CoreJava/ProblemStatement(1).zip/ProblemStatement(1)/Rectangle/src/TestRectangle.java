
public class TestRectangle {
	 int n = 6;
	 int l;
	 int b;
	 Rectangle []rect;
	public void App(){
	
	for (int i = 0; i < n; i++) {
		Rectangle[] rect = new Rectangle[n] ; 
		rect[i] = new Rectangle(l, b);
		}
	for (int i = 0; i < n; i++) {
        System.out.println(rect[i].getprintArea());
    }
}
	 }
