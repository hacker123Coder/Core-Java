
public class CalRec {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(2, 4);   
		
		r1.getprintArea();
		r1.printData();
		
		r2.getprintArea();
		r2.printData();

	}
}
   class Rectangle {
	private int length;
	private int breadth;

  //Getters $ Setters
	
	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	//default constructor
	public Rectangle() {
	}

	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}
	
	public void printData() {
		System.out.println("Length: " + length);
		System.out.println("Breadth: " + breadth);
	}

	
	public int getprintArea() {
		int area = length * breadth;
		System.out.println("Area: " + area);
		return area;
	}

	
	
}