package com.akshay.training;

public abstract class Instrument {
abstract void play();
}
