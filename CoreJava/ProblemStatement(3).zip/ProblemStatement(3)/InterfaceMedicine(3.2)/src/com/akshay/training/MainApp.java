package com.akshay.training;

import java.util.Random;

public class MainApp {

	public static void main(String[] args) {
    
	MedicineInfo[]medicine=new MedicineInfo[10];
	//Random is java utiliy class that creates random number
			Random random = new Random();
			
			for (int i = 0; i < 10; i++) {
			
			//It creates random number from 1 to 3
			//Provide the min and max number basically the range 
		    
			int randomNum = new Random().nextInt(1, 4);
		    
			if (randomNum == 1)
	    		medicine[i] = new Syrup();
	    	
			else if (randomNum == 2)
	    		medicine[i] = new Ointment();
	    	
			else if (randomNum == 3)
	    		medicine[i] = new Tablet();
	    	
	    	medicine[i].displayLabel();
	    }
	    
	    for (int i = 0; i < 10; i++) {
	    	
	    	if (medicine[i] instanceof Syrup) 
	    		System.out.println("Syrup is stored at index " + i);
	    	
	    	else if (medicine[i] instanceof Ointment) 
	    		System.out.println("Ointment is stored at index " + i);
	    	
	    	else if (medicine[i] instanceof Tablet) 
	    		System.out.println("Tablet is stored at index " + i);
	    }

	}

}
