package com.akshay.training;

public class Tablet implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("Store in a cool and dry place");		
	}

}
