package com.akshay.training;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLabel() {
    System.out.println("Take 5ml of syrup");		
	}

}
