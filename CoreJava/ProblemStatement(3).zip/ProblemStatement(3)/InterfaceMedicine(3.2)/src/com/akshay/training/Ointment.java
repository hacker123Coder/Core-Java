package com.akshay.training;

public class Ointment implements MedicineInfo {

	@Override
	public void displayLabel() {
   System.out.println("External use only");		
	}

}
