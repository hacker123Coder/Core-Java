package com.akshay.training;

public interface MedicineInfo {

	void displayLabel();
}
