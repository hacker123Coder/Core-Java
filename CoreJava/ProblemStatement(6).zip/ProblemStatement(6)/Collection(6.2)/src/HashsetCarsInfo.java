import java.util.HashSet;
import java.util.Hashtable;
import java.util.Scanner;

public class HashsetCarsInfo {
	public static void main(String[] args)
    {
 
       Hashtable<String,String> hm=new Hashtable<String,String>();
       Scanner scan = new Scanner(System.in);
       
       for(int i=0; i<=1; i++) {
    	   
    	   System.out.println("enter the name and id of the product:");
    	   String pid = scan.next();
    	   String pname = scan.next();
    	   hm.put(pid, pname);
       }
       //Printing the hash table
       
       System.out.println(hm);
       
       //Search thro hash table
       	   
       	   System.out.println("Enter the id to be searched");
       	   String s1=scan.next();
      
       	   System.out.println(hm.get(s1));
       //Delete thro hash table
       	   
       	   System.out.println("Enter the id to be deleted");
       	   String s2=scan.next();
       	   System.out.println(hm.remove(s2));
       	   
       	//Check whether it is deleted
       	   
       	  System.out.println(hm.toString());

		
}
}
