import java.util.ArrayList;
import java.util.Scanner;

public class StudentNameArrayList {
	public static void main(String[] args)
    {
  
        
         ArrayList<String> arr = new ArrayList<String>(4);
  
        arr.add("akshay");
        arr.add("anil");
        arr.add("sandy");
  
       Scanner scan =new Scanner(System.in);
       System.out.println("enter the name to find");
       String str = scan.next();
        
       boolean ans = arr.contains(str);
        
        if (ans)
            System.out.println("The list contains "+str);
        else
            System.out.println("The list does not contains "+str);
  
       
        
    }
}

