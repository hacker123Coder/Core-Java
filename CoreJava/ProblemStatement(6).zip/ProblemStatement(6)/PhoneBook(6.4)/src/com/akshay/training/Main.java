package com.akshay.training;
import java.util.*;

public class Main {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
        int i=0;
        PhoneBook objmain=new PhoneBook();
        while(i==0)
        {
            System.out.println("Menu\n1.Add Contact\n"
            		+ "2.Display all contacts\n"
            		+ "3.Search contact by phone\n"
            		+ "4.Exit");
            System.out.println("Enter your choice: ");
            int n=Integer.parseInt(sc.nextLine());
            if(n==1)
            {
                Contact obj=new Contact();
                System.out.println("Add a contact: ");
                System.out.println("Enter the First Name: ");
                obj.setFirstName(sc.nextLine());
               
                System.out.println("Enter the Phone No. : ");
                obj.setPhoneNumber(Long.parseLong(sc.nextLine()));
                
                objmain.addContact(obj);
                System.out.println("Contact added sucessfully");
            }
            if(n==2)
            {
                System.out.println("The contacts in the List are:");
                List<Contact>obj=objmain.viewAllContacts();
                for(Contact temp:obj)
                {
                    System.out.println("First Name:"+temp.getFirstName());
                    System.out.println("Phone No.:"+temp.getPhoneNumber());
                    
                }
            }
            if(n==3)
            {
                System.out.println("Enter the Phone number to search contact:");
                Long n1=Long.parseLong(sc.nextLine());
                Contact obj1=objmain.viewContactGivenPhone(n1);
                System.out.println("The contact is:");
                System.out.println("First Name:"+obj1.getFirstName());
                System.out.println("Phone No.:"+obj1.getPhoneNumber());
            }
            
                   
                
            
            if(n==4)
            {
                System.exit(0);
            }
        }
    }

}
