package com.akshay.training;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class Main {
	private static final Employee[] v = null;

	public static void main(String[] args) {
		LinkedList<Employee> v = addInput();
		display(v);
	}

	private static LinkedList<Employee> addInput() {
		Employee e1 = new Employee(101, "Akshay", "Mumbai");
		Employee e2 = new Employee(102, "Kesi", "L/A");
		Employee e3 = new Employee(103, "Shishir", "Mumbai");
		LinkedList<Employee> v = new LinkedList<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
	}

	private static void display(LinkedList<Employee> v) {
		for (Employee e : v) {
			System.out.println(e.getEmpid() + "\t" + e.getEname() + "\t" + e.getAddress());
		}
//		Iterator it = v.iterator();
		ListIterator it2 = v.listIterator();
	      while (it2.hasNext()) {
	         System.out.println(it2.next());
	      }
	      System.out.println("--------------------------------------------");
	      System.out.println("Iterating the elements in backward direction: ");
	      
	      
	      while (it2.hasPrevious()) {
	         System.out.println(it2.previous());
	      }
	}

}