import java.util.Arrays;

public class MainApp {
public static void main(String[] args) {
	
	int a[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	//To find smallest number
	int b[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2};
	Arrays.sort(b);
	
	int res= 0;
	int	resavg=0;
	int temp;
	
	for(int i= 0; i<= a.length-4;i++) {
		
		   	  
		//To calculate the sum 
		res=res+a[i];
		
		//To calculate avg
	   	resavg=res/14;
	   	
	   
	   	
		 	
	   
	}
	
	System.out.println("result of sum:"+   res);
	System.out.println("result of avg:"+   resavg);
	System.out.println("smallest number is:"+ b[0]);
	
	a[15]=res;
	a[16]=resavg;
	a[17]=b[0];
	
	for(int i=0; i<=a.length-1;i++) {
		System.out.print(a[i]);
	}
	}
 
}  


