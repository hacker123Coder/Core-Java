
public class StringDelim {
public static void main(String[] args) {
	
	String str = "23  +      45   - (   343   /   12 ) ";
	String delims = "[ ]+";
	String[] tokens = str.split(delims);
	for (int i = 0; i < tokens.length; i++)
	    System.out.println(tokens[i]);

}
}
