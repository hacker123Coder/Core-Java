import java.util.Arrays;
import java.util.stream.Collectors;

public class MainApp {

	public static void main(String[] args) {
		StringTransform txt= new StringTransform();
		txt.Upper();
		txt.Lower();
		txt.Split();
		txt.LastToFirst();
		txt.RevWords();
		txt.LengthOfString();
	}
  
}
  class StringTransform {
	  
	  String str = "JAVA is Simple";
	  
	  // Converts String to UpperCase
	  public void Upper() {
		System.out.println(str.toUpperCase());
	} 
	 
	  // Converts String to LowerCase
	  public void Lower() {
		 System.out.println(str.toLowerCase());
	 }
	 
	  // Prints only the first char of each word
	  public void Split() {
	   
		String[] words=str.split("\\s");//splits the string based on string
		
		for(String w:words){
		System.out.print(w.charAt(0)+" ");
		}
	}
	
	  //Prints last word of string at first place
	  public void LastToFirst() {
		
		  String s1=str.substring(str.lastIndexOf("Simple"));
		  
		  System.out.println("\n");
		  
		  
		  System.out.println(s1+" "+str.replaceAll("\\s", "").substring(0, 6));
	}
  
  
      public void RevWords() {
    	  String result = Arrays.asList(str.split(" "))
                  .stream()
                  .map(s -> new StringBuilder(s).reverse())
                  .collect(Collectors.joining(" "));
   
          System.out.println(result);
   
	
     }
  
  
  public void LengthOfString() {
	
	  int length=str.length();
	
	  System.out.println("Length of a string is: "+length);
     }
  
  
  }