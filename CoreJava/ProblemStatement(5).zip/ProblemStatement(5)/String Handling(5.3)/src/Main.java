import java.util.Iterator;

public class Main {

	public static void main(String[] args) {
		
		String str= "MPHASIS";
		for(int i=0; i<=str.length()-1; i++) {
		
		
		String str1= str.substring(1);
		String str2=str1+str.charAt(0);
		
		System.out.println(str2);
		str =str2;
	}
		}
}
